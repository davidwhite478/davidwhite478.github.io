from flask import Flask, request, render_template, redirect, \
		url_for, session, flash, g, send_from_directory
from functools import wraps
from werkzeug import secure_filename
import sqlite3
import os
from form import LoginForm, RegisterForm
import bcrypt
import re
from PIL import Image

IMAGE_UPLOAD_FOLDER = os.path.abspath("./uploaded_images")
THUMBNAIL_PATH = "thumbnails"
THUMBNAIL_MAX_DIM = 300
ALLOWED_EXTENSIONS = set(['png', 'jpg', 'jpeg', 'gif'])

app = Flask(__name__)

app.secret_key = os.urandom(24)
app.database = "siteDatabase.db"
app.config['IMAGE_UPLOAD_FOLDER'] = IMAGE_UPLOAD_FOLDER

# login required decorator
def login_required(f):
	@wraps(f)
	def wrap(*args, **kwargs):
		if 'user_id' in session:
			return f(*args, **kwargs)
		else:
			session.pop('user_id', None)
			flash('You need to login first.')
			return redirect(url_for('login'))
	return wrap

# not logged in required decorator
def not_logged_in_required(f):
	@wraps(f)
	def wrap(*args, **kwargs):
		if 'user_id' in session:
			flash('You are already logged in!')
			return redirect(url_for('gallery'))
		else:
			session.pop('user_id', None)
			return f(*args, **kwargs)
	return wrap

def allowed_file(filename):
	return '.' in filename and \
		   filename.rsplit('.', 1)[1] in ALLOWED_EXTENSIONS

@app.route('/upload', methods=['GET', 'POST'])
@login_required
def upload():
	if request.method == 'POST':
		file = request.files['file']
		if file and allowed_file(file.filename):
			filename = secure_filename(file.filename)
			filePath = os.path.join(app.config['IMAGE_UPLOAD_FOLDER'], session['user_id'])
			if not os.path.exists(filePath):
				os.makedirs(filePath)
				
			filecount = 2
			splitFile = os.path.splitext(filename)
			while os.path.isfile(os.path.join(filePath, filename)):
				filename = splitFile[0] + " ("+str(filecount)+")"+splitFile[1]
				filecount+=1

			file.save(os.path.join(filePath, filename))

			original = Image.open(os.path.join(filePath, filename))

			if original.size[0] < original.size[1]:
				scaleFactor = THUMBNAIL_MAX_DIM / original.size[0]
			else:
				 scaleFactor = THUMBNAIL_MAX_DIM / original.size[1]

			thumbSize = (original.size[0]*scaleFactor, original.size[1]*scaleFactor)

			thumbnailPath = os.path.join(filePath, THUMBNAIL_PATH)

			if not os.path.exists(thumbnailPath):
				os.makedirs(thumbnailPath)

			original.thumbnail(thumbSize, Image.ANTIALIAS)

			fileType = splitFile[1][1:]

			if fileType.upper() == "JPG":
   				fileType = "JPEG"

			original.save(os.path.join(thumbnailPath, filename), fileType)

			addFileToDb(filename, session['user_id'])
			return redirect(url_for('gallery',
									new_file=filename))

	return render_template("upload.html", username=session['user_id'])


@app.route('/', methods=['GET', 'POST'])
def homeRedirect():
	if 'user_id' in session:
		return redirect(url_for('gallery'))
	else:
		flash('Please login.')
		return redirect(url_for('login'))			

@app.route('/uploads/<user>/<filename>')
@login_required
def uploaded_file(user, filename):
	if session['user_id'] == user:
		return send_from_directory(os.path.join(app.config['IMAGE_UPLOAD_FOLDER'], user),
								   filename)
	else:
		flash('You need to login to the correct account to view this image.')
		return redirect(url_for('gallery'))

@app.route('/thumbnail/<user>/<filename>')
@login_required
def get_thumbnail(user, filename):
	if session['user_id'] == user:
		return send_from_directory(os.path.join(app.config['IMAGE_UPLOAD_FOLDER'], user, THUMBNAIL_PATH),
		 filename)
	else:
		flash('You need to login to the correct account to view this image.')
		return redirect(url_for('gallery'))

def check_username(username):
	g.db = connect_db()
	cur = g.db.execute("select * from Users where Username='"+username+"'")
	username_list = cur.fetchall()
	g.db.close()

	if len(username_list) != 1:
		return None
	else:
		return username_list[0][2] # Return hashed password


@app.route("/login", methods=['GET', 'POST'])
@not_logged_in_required
def login():
	error = None
	errorMessage = 'Invalid Credentials. Please try again.'
	form = LoginForm(request.form)
	if request.method == 'POST':
		if form.validate_on_submit():
			hashed_pass = check_username(form.username.data)
			if not hashed_pass: # If None
				error = errorMessage
			else:
				if bcrypt.hashpw(form.password.data.encode('utf-8'), hashed_pass) == hashed_pass:
					#flash("You were just logged in!")
					session['user_id'] = form.username.data
					return redirect(url_for('gallery'))
				else:
					error = errorMessage
					return render_template("login.html", form=form, error=error)
		else:
			return render_template("login.html", form=form, error=error)
			
	return render_template("login.html", form=form, error=error)

@app.route("/logout")
@login_required
def logout():
	session.pop('user_id', None)
	session.pop('viewTag', None)
	flash("You were just logged out!")
	return redirect(url_for('login'))

def createUser(username, password):
	hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt(rounds=12))

	with sqlite3.connect(app.database) as connection:
		c = connection.cursor()
		sql_statement = 'INSERT into Users (Username, Password) VALUES (\"'+username+'\",?)'
		c.execute(sql_statement, (sqlite3.Binary(hashed_password),))

@app.route("/register", methods=['GET', 'POST'])
@not_logged_in_required
def register():
	error = None
	errorMessage = 'Invalid Credentials. Please try again.'
	takenMessage = "That username is not available. Please try again."
	form = RegisterForm(request.form)
	if request.method == 'POST':
		if form.validate_on_submit():
			if check_username(form.username.data):
				error = takenMessage
				render_template("register.html", form=form, error=error)
			else:
				# create user
				createUser(form.username.data, form.password.data)

				flash("Account creation successful! - Username: "+form.username.data+".")
				return redirect(url_for('login'))
		else:
			return render_template("register.html", form=form, error=error)

	return render_template("register.html", form=form, error=error)

@app.route("/sortTag/<tag>", methods=['GET'])
@login_required
def sortTag(tag):
	if userHasTag(session['user_id'], tag):
		session['viewTag'] = tag
		return redirect(url_for('gallery'))
	else:
		return redirect(url_for('gallery'))

@app.route("/removeTags", methods=['GET'])
@login_required
def removeTags():
	session.pop('viewTag', None)
	return redirect(url_for('gallery'))

@app.route("/removeImage/<user>/<filename>", methods=['GET'])
@login_required
def removeImage(user, filename):
	if user == session['user_id']:
		filePath = os.path.join(app.config['IMAGE_UPLOAD_FOLDER'], user, filename)
		thumbnailPath = os.path.join(app.config['IMAGE_UPLOAD_FOLDER'], user, THUMBNAIL_PATH, filename)

		if os.path.isfile(filePath):
			os.remove(filePath)

		if os.path.isfile(thumbnailPath):
			os.remove(thumbnailPath)

		with sqlite3.connect(app.database) as connection:
			c = connection.cursor()
			c.execute('delete from images where User_ID="'+user+'" and filename="'+filename+'"')
			c.execute('delete from Tags where Username="'+user+'" and Filename="'+filename+'"')

		flash('Removed image: '+filename)
		return redirect(url_for('gallery'))
	else:
		flash('You cannot delete that image')
		return redirect(url_for('gallery'))

@app.route("/removeTag/<tag>/<user>/<filename>", methods=['GET'])
@login_required
def removeTag(tag, user, filename):
	if user == session['user_id']:
		
		with sqlite3.connect(app.database) as connection:
			c = connection.cursor()
			c.execute('delete from Tags where Username="'+user+'" and Filename="'+filename+'" and Tag="'+tag+'"')

		flash('Removed tag: '+tag)
		return redirect(url_for('image', user=user, filename=filename))
	else:
		flash('You cannot remove the tag from that image')
		return redirect(url_for('gallery'))

@app.route("/gallery", methods=['GET'])
@login_required
def gallery():
	if 'viewTag' in session:
		viewTag = session['viewTag']
	else:
		viewTag = None
	g.db = connect_db()
	if viewTag is None:
		cur = g.db.execute('select User_ID, filename from images WHERE User_ID="'+session['user_id']+'" ORDER BY Image_ID DESC')
	else:
		cur = g.db.execute('select Username, Filename from Tags WHERE Username="'+session['user_id']+'" and Tag="'+viewTag+'" ORDER BY Tag_ID DESC')

	images = [dict(user=row[0], filename=row[1]) for row in cur.fetchall()]
	g.db.close()
	newFilename = request.args.get('new_file')
	return render_template("gallery.html", images=images, newFilename=newFilename, username=session['user_id'], tags=getAllTags(session['user_id']),
		currentTag=viewTag)

@app.route('/image/<user>/<filename>', methods=['GET', 'POST'])
@login_required
def image(user, filename):
	#Check if image exists first, and that session user equals user
	g.db = connect_db()
	cur = g.db.execute('select Image_ID from images WHERE User_ID="'+user+'" and filename="'+filename+'"')
	images = cur.fetchall()
	g.db.close()
	if len(images) != 0:
		if user == session['user_id']:
			if request.method == 'GET':
				return render_template("image.html", image=filename, username=user, tags=getImageTags(user, filename), tagError=None)
			else:
				newTag = request.form['newTag']

				newTag = newTag.strip()

				newTag = newTag.lower()

				if re.match('^[a-zA-Z0-9_ ]+$',newTag) and len(newTag) <= 40:
					if imageHasTag(user, filename, newTag):
						tagError = "This image is already tagged with the term - '"+newTag+"'."
						return render_template("image.html", image=filename, username=user, tags=getImageTags(user, filename), tagError=tagError)
					else:
						addTagToImage(user, filename, newTag)
						flash("Added new tag: '"+newTag+"'")
						return render_template("image.html", image=filename, username=user, tags=getImageTags(user, filename), tagError=None)
				else:
					if len(newTag) > 0:
						if len(newTag) <= 40:
							tagError = "Tags can only contain letters, numbers, underscores and spaces."
						else:
							tagError = "Tags must be less than 40 characters."
					else:
						tagError = "You must type a tag to add it."
					return render_template("image.html", image=filename, username=user, tags=getImageTags(user, filename), tagError=tagError)

		else:
			flash('You do not have access to that image.')
			return redirect(url_for('gallery'))
	else:
		flash('That image does not exist!')
		return redirect(url_for('gallery'))

def imageHasTag(username, filename, tag):
	g.db = connect_db()
	cur = g.db.execute('select Tag from Tags WHERE Filename="'+filename+'" and Username="'+username+'" and Tag="'+tag+'" ORDER BY Tag_ID')
	tags = cur.fetchall()
	g.db.close()
	if len(tags) > 0:
		return True
	else:
		return False

def userHasTag(username, tag):
	g.db = connect_db()
	cur = g.db.execute('select DISTINCT Tag from Tags WHERE Username="'+username+'" and Tag="'+tag+'"')
	tags = cur.fetchall()
	g.db.close()
	if len(tags) > 0:
		return True
	else:
		return False

def getAllTags(username):
	g.db = connect_db()
	cur = g.db.execute('select DISTINCT Tag from Tags WHERE Username="'+username+'" ORDER BY Tag')
	tags = cur.fetchall()
	g.db.close()
	return tags

def getImageTags(username, filename):
	g.db = connect_db()
	cur = g.db.execute('select Tag from Tags WHERE Filename="'+filename+'" and Username="'+username+'" ORDER BY Tag_ID')
	tags = cur.fetchall()
	g.db.close()
	return tags

def addTagToImage(username, filename, tag):
	with sqlite3.connect(app.database) as connection:
		c = connection.cursor()
		c.execute("INSERT INTO Tags (Filename, Username, Tag) VALUES(\""+filename+"\",\""+username+"\",\""+tag+"\")")

def addFileToDb(filename, username):
	with sqlite3.connect(app.database) as connection:
		c = connection.cursor()
		c.execute("INSERT INTO images (filename, User_ID) VALUES(\""+filename+"\",\""+username+"\")")

def connect_db():
	return sqlite3.connect(app.database)


if __name__ == "__main__":
	app.run(debug=True)