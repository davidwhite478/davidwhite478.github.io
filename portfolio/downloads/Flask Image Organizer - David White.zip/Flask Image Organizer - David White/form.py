from flask_wtf import Form
from wtforms import TextField, PasswordField
from wtforms.validators import DataRequired, Regexp, Length

regularExpression = '^[a-zA-Z0-9_]+$'

regularExMessage = "letters, numbers or underscores."

class LoginForm(Form):
	username = TextField('Username', validators=[DataRequired(message="You must enter a username."),
		Regexp(regularExpression, message="Username must contain only "+regularExMessage)])
	password = PasswordField('Password', validators=[DataRequired(message="You must enter a password."),
		Regexp(regularExpression, message="Passwords must contain only "+regularExMessage)])

class RegisterForm(Form):
	username = TextField('Username', validators=[DataRequired(message="You must enter a username."), 
		Regexp(regularExpression, message="Username must contain only "+regularExMessage),
		Length(min=3, max=25, message="Username must be between 3 and 30 characters.")])
	password = PasswordField('Password', validators=[DataRequired(message="You must enter a password."),
	Regexp(regularExpression, message="Passwords must contain only "+regularExMessage), 
		Length(min=6, max=25, message="Password must be between 6 and 30 characters.")])