package sample;

import javafx.application.Platform;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.io.*;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import java.io.RandomAccessFile;

import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

import java.security.SecureRandom;

import java.lang.Exception;

public class ServerCommunicator implements MqttCallback{

    public MqttClient client;

    private Cipher cipher;

    private SecretKeySpec specKey;

    private String chatRoom = "None";

    private String clientId = "None";

    private String displayedChatRoom = "None";

    public String receivedFilesPath = "None";

    public KeepAliveThread keepAliveThread = null;

    public static final long keepAliveInterval = 45*1000; // Every 45 seconds

    private Controller windowController;

    public boolean requestingOnlineStatus = false;

    // The constructor is given the constructor to allow it to be able to
    // communicate back with the GUI
    public ServerCommunicator(Controller theController) {
        windowController = theController;
    }

    // This function concatenates two byte arrays together and returns the result
    public static byte[] concatenateByteArray(byte[] array1, byte[] array2) {
        int oneLength = array1.length;

        int twoLength = array2.length;

        byte[] finalArray = new byte[oneLength+twoLength];

        System.arraycopy(array1, 0, finalArray, 0, oneLength);
        System.arraycopy(array2, 0, finalArray, oneLength, twoLength);
        return finalArray;
    } // concatenateByteArray()

    // This function is used by the Controller to specify the clientId, chatRoom etc.
    public void setupVariables(String baseChatRoom, String newClientId, String newChatRoom, String newFilePath){

        if (client != null && client.isConnected())
            disconnectFromServer(); // Allows for changing of room/name

        clientId = newClientId;
        chatRoom = baseChatRoom+newChatRoom;
        receivedFilesPath = newFilePath;

        displayedChatRoom = newChatRoom;
    } // setupVariables()

    // This function sets up the symmetric key, connection and requests all online clients
    public void setupAll(){
        try {
            setupSymmetricKey();
            setupConnection();

            requestingOnlineStatus = true;
            requestAllOnline();
        }
        catch (Exception e){
            System.err.println("An error occurred whilst connecting to the server.");
        }

        if (client != null && client.isConnected()){
            Platform.runLater(() -> windowController.successfulConnectionUpdate());
        }else{
            Platform.runLater(() -> windowController.failedConnectionUpdate());
        }
    } // setupAll()

    // This function (currently unused) creates a directory for the received files
    public void setupDirectory(){
        File directory = new File(receivedFilesPath);

        if (!directory.isDirectory()){
            boolean successful = directory.mkdir();

            if (successful)
                System.err.println("Successfully Created Directory.");
            else
                System.err.println("Failed Creating Directory!");
        }
    } // setupDirectory()

    // This function sets up the symmetric key - currently fixed, but should
    // establish the key between clients for more security
    public void setupSymmetricKey() throws Exception{
        cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");

        byte[] keyBytes = "*q6-3._a".getBytes();

        specKey = new SecretKeySpec(keyBytes, "DES");
    } // setupSymmetricKey()

    // This function connects to the server using the set-up variables
    // It also starts a thread to send a keep alive message to the server
    // ast a preset interval
    public void setupConnection(){
        try {
            client = new MqttClient("tcp://iot.eclipse.org:1883", clientId);
            client.connect();
            client.setCallback(this);
            client.subscribe(chatRoom);
            announceOnlineStatus(true);

            if (keepAliveThread == null){
                keepAliveThread = new KeepAliveThread(this);
                keepAliveThread.start();
            }
        } catch (MqttException e) {
            e.printStackTrace();
        }
    } // setupConnection()

    // This function disconnects from the server (if connected) with also
    // announcing offline status to other clients before disconnecting
    public void disconnectFromServer(){
        try {
            announceOnlineStatus(false);
            client.disconnect();
            if(keepAliveThread != null){
                keepAliveThread.interrupt();
            }
        } catch (MqttException e) {
            e.printStackTrace();
        }
    } // disconnectFromServer()

    // This function sends a message to the server to keep the connection alive, as
    // by default the connection will time out after a short period
    public void keepAlive(){
        if(client != null && client.isConnected()){
            MqttMessage message = new MqttMessage();
            message.setPayload("A".getBytes());
            boolean sent = false;
            while(!sent){
                try{
                    client.publish(Controller.baseTopic+"/alive", message);
                    System.out.println("Sent KeepAlive");
                    sent = true;
                } catch (MqttException e){
                    System.err.println("Error in sending keepAlive! Trying Again...");
                }
            }
        } else {
            System.out.println("Cannot send keepAlive as not connected.");
        }
    } // keepAlive()

    // This function sends out a message to all other clients, requesting their names
    // to find out who is online
    public void requestAllOnline(){
        try {
            System.out.println("Requesting All Online Clients.");

            byte[] requestAsBytes;

            requestAsBytes = "O".getBytes();

            // Encrypting

            SecureRandom random = new SecureRandom();

            byte initVector[] = new byte[8];

            random.nextBytes(initVector);

            IvParameterSpec ivSpec = new IvParameterSpec(initVector);

            cipher.init(Cipher.ENCRYPT_MODE, specKey, ivSpec);
            byte[] encrypted = new byte[cipher.getOutputSize(requestAsBytes.length)];
            int enc_len = cipher.update(requestAsBytes, 0, requestAsBytes.length, encrypted, 0);
            enc_len += cipher.doFinal(encrypted, enc_len);

            //String encodedKey = Base64.getEncoder().encodeToString(key.getEncoded());

            //System.out.println("Key: " + encodedKey);

            // Put IV at start:

            byte[] encryptedFullMessage = concatenateByteArray(initVector, encrypted);

            //encryptedFullMessage = concatenateByteArray(encodedKey.getBytes(), encryptedFullMessage);

            // Sending...

            MqttMessage message = new MqttMessage();
            message.setPayload(encryptedFullMessage);

            client.unsubscribe(chatRoom);
            client.publish(chatRoom, message); // Change this
            client.subscribe(chatRoom);

        } catch (MqttException e) {
            e.printStackTrace();
        } catch (Exception e){
            System.err.println("Error Occurred Whilst Getting Online Clients: "+e.getMessage());
        }
    } // requestAllOnline()

    // This function is called whenever a request is received for online client status.
    // The function sends a list of all of the current online clients
    public void sendingAllOnlineClients(){
        try {
            requestingOnlineStatus = false;
            System.out.println("Sending All Online Clients.");

            String onlineRequest = "B";

            boolean first = true;

            for (String i : windowController.onlineClients){
                if (first){
                    onlineRequest+=i;
                    first = false;
                } else{
                    onlineRequest+="/#/"+i;
                }
            }
            byte[] requestAsBytes;

            requestAsBytes = onlineRequest.getBytes();

            // Encrypting

            SecureRandom random = new SecureRandom();

            byte initVector[] = new byte[8];

            random.nextBytes(initVector);

            IvParameterSpec ivSpec = new IvParameterSpec(initVector);

            cipher.init(Cipher.ENCRYPT_MODE, specKey, ivSpec);
            byte[] encrypted = new byte[cipher.getOutputSize(requestAsBytes.length)];
            int enc_len = cipher.update(requestAsBytes, 0, requestAsBytes.length, encrypted, 0);
            enc_len += cipher.doFinal(encrypted, enc_len);

            //String encodedKey = Base64.getEncoder().encodeToString(key.getEncoded());

            //System.out.println("Key: " + encodedKey);

            // Put IV at start:

            byte[] encryptedFullMessage = concatenateByteArray(initVector, encrypted);

            //encryptedFullMessage = concatenateByteArray(encodedKey.getBytes(), encryptedFullMessage);

            // Sending...

            MqttMessage message = new MqttMessage();
            message.setPayload(encryptedFullMessage);

            client.unsubscribe(chatRoom);
            client.publish(chatRoom, message); // Change this
            client.subscribe(chatRoom);

        } catch (MqttException e) {
            e.printStackTrace();
        } catch (Exception e){
            System.err.println("Error Occurred Whilst Getting Online Clients: "+e.getMessage());
        }
    } // sendingAllOnlineClients()

    // This function is called upon the user coming online or going offline. It is
    // a message to tell other users in the session so that they can add or remove
    // the user
    public void announceOnlineStatus(boolean online){
        try {
            System.out.println("Announcing online/offline status.");

            byte[] announcementAsBytes;
            if (online){
                announcementAsBytes = ("AY"+clientId).getBytes();
            }
            else{
                announcementAsBytes = ("AN"+clientId).getBytes();
            }

            // Encrypting

            SecureRandom random = new SecureRandom();

            byte initVector[] = new byte[8];

            random.nextBytes(initVector);

            IvParameterSpec ivSpec = new IvParameterSpec(initVector);

            cipher.init(Cipher.ENCRYPT_MODE, specKey, ivSpec);
            byte[] encrypted = new byte[cipher.getOutputSize(announcementAsBytes.length)];
            int enc_len = cipher.update(announcementAsBytes, 0, announcementAsBytes.length, encrypted, 0);
            enc_len += cipher.doFinal(encrypted, enc_len);

            //String encodedKey = Base64.getEncoder().encodeToString(key.getEncoded());

            //System.out.println("Key: " + encodedKey);

            // Put IV at start:

            byte[] encryptedFullMessage = concatenateByteArray(initVector, encrypted);

            //encryptedFullMessage = concatenateByteArray(encodedKey.getBytes(), encryptedFullMessage);

            // Sending...

            MqttMessage message = new MqttMessage();
            message.setPayload(encryptedFullMessage);

            client.unsubscribe(chatRoom);
            client.publish(chatRoom, message); // Change this
            client.subscribe(chatRoom);

        } catch (MqttException e) {
            e.printStackTrace();
        } catch (Exception e){
            System.err.println("Error Occurred Whilst Announcing Online Status: "+e.getMessage());
        }
    } // announceOnlineStatus()

    // This function converts a filepath to just the filename - removing the
    // directories
    public String getFilename(String filepath){
        String[] splitFilename;

        // Remove / (linux) or \ (windows) from filepath
        if (filepath.indexOf('/') >= 0)
            splitFilename = filepath.split("/");
        else
            splitFilename = filepath.split("\\\\");

        return splitFilename[splitFilename.length-1];
    } // getFilename()

    // This function generated a filename appended with a timecode which 'ensures'
    // that all files have unique filenames and all users in session have
    // files with the same names
    public String getSentFilename(String filepath){
        String filename = getFilename(filepath);

        String[] filenameDotRemoved = filename.split("\\.");

        LocalDateTime timePoint = LocalDateTime.now();

        String timeString = timePoint.format(DateTimeFormatter.ISO_LOCAL_DATE_TIME).split("\\.")[0].replaceAll(":","").replaceAll("-","").replaceAll("T","");

        return filenameDotRemoved[0]+" ["+timeString+"]."+filenameDotRemoved[1];
    } // getSentFilename()

    // This function sends the given file (encrypted) to other users in the session
    public void sendFile(String filepath, String filename){
        try {
            System.out.println("Sending File: ["+filename+"]");

            RandomAccessFile file = new RandomAccessFile(filepath, "r");
            byte[] fileByteArray = new byte[(int)file.length()];
            file.read(fileByteArray);

            // Also add S to start to indicate sent file
            byte[] filenameAsBytes = ("S"+filename+"/").getBytes();

            byte[] fullMessage = concatenateByteArray(filenameAsBytes, fileByteArray);

            // Encrypting

            SecureRandom random = new SecureRandom();

            byte initVector[] = new byte[8];

            random.nextBytes(initVector);

            IvParameterSpec ivSpec = new IvParameterSpec(initVector);

            cipher.init(Cipher.ENCRYPT_MODE, specKey, ivSpec);
            byte[] encrypted = new byte[cipher.getOutputSize(fullMessage.length)];
            int enc_len = cipher.update(fullMessage, 0, fullMessage.length, encrypted, 0);
            enc_len += cipher.doFinal(encrypted, enc_len);

            //String encodedKey = Base64.getEncoder().encodeToString(key.getEncoded());

            //System.out.println("Key: " + encodedKey);

            // Put IV at start:

            byte[] encryptedFullMessage = concatenateByteArray(initVector, encrypted);

            //encryptedFullMessage = concatenateByteArray(encodedKey.getBytes(), encryptedFullMessage);

            // Sending...

            MqttMessage message = new MqttMessage();
            message.setPayload(encryptedFullMessage);

            client.unsubscribe(chatRoom);
            client.publish(chatRoom, message); // Change this part to make not un-subscribe but just ignore messages from self
            // Or could have 2 client IDs - one send, one receive
            client.subscribe(chatRoom);

            Platform.runLater(() -> windowController.sendSuccessfulUpdate());

        } catch (MqttException e) {
            e.printStackTrace();
            Platform.runLater(() -> windowController.sendFailedUpdate());
        } catch (FileNotFoundException e) {
            System.err.println("FILE NOT FOUND - " + filepath);
            Platform.runLater(() -> windowController.sendFailedUpdate());
        } catch (IOException e) {
            System.err.println(e.getMessage());
            Platform.runLater(() -> windowController.sendFailedUpdate());
        } catch (Exception e){
            System.err.println(e.getMessage());
            Platform.runLater(() -> windowController.sendFailedUpdate());
        }
    } // sendFile()

    // This function tells other connected users to change to the given
    // filename in an encrypted message
    public void sendChangeRequest(String filepath){
        try {
            String[] splitFilename;

            // Remove / (linux) or \ (windows) from filepath
            if (filepath.indexOf('/') >= 0)
                splitFilename = filepath.split("/");
            else
                splitFilename = filepath.split("\\\\");

            String filename = splitFilename[splitFilename.length-1];

            System.out.println("Requesting Change To File: ["+filename+"]");

            byte[] changeRequestAsBytes = ("C"+filename).getBytes();

            // Encrypting

            SecureRandom random = new SecureRandom();

            byte initVector[] = new byte[8];

            random.nextBytes(initVector);

            IvParameterSpec ivSpec = new IvParameterSpec(initVector);

            cipher.init(Cipher.ENCRYPT_MODE, specKey, ivSpec);
            byte[] encrypted = new byte[cipher.getOutputSize(changeRequestAsBytes.length)];
            int enc_len = cipher.update(changeRequestAsBytes, 0, changeRequestAsBytes.length, encrypted, 0);
            enc_len += cipher.doFinal(encrypted, enc_len);

            //String encodedKey = Base64.getEncoder().encodeToString(key.getEncoded());

            //System.out.println("Key: " + encodedKey);

            // Put IV at start:

            byte[] encryptedFullMessage = concatenateByteArray(initVector, encrypted);

            //encryptedFullMessage = concatenateByteArray(encodedKey.getBytes(), encryptedFullMessage);

            // Sending...

            MqttMessage message = new MqttMessage();
            message.setPayload(encryptedFullMessage);

            client.unsubscribe(chatRoom);
            client.publish(chatRoom, message); // Change this
            client.subscribe(chatRoom);

        } catch (MqttException e) {
            e.printStackTrace();
        } catch (Exception e){
            System.err.println("Error Occurred Whilst Requesting Change: "+e.getMessage());
        }
    } // sendChangeRequest()

    // This function is called upon disconnecting from the session
    @Override
    public void connectionLost(Throwable cause) {
        // TODO Auto-generated method stub
        System.out.println("Connection Lost...!");
        // NEED TO FIX THIS - MAKE THE CONNECTION RESTART
    } // connectionLost()

    // This function converts a filename with an appended timecode to
    // the original filename without the timecode
    public static String getOriginalFilename(String filename){
        String[] splitFilename = filename.split(" ");

        filename = "";

        for(int i = 0; i < splitFilename.length-1; i++){
            filename+=splitFilename[i];

            if (i != splitFilename.length-2){
                filename+=" ";
            }
        }

        filename+="."+splitFilename[splitFilename.length-1].split("\\.")[1];

        return filename;
    } // getOriginalFilename()

    // This function is called upon the arrival of any message.
    // The function decrypts the message, parses it and performs
    // the correct function
    @Override
    public void messageArrived(String topic, MqttMessage message)
            throws Exception {
        System.out.println("Message Received!");
        byte[] fullmessage = message.getPayload();

        byte[] initVector = Arrays.copyOfRange(fullmessage, 0, 8);

        IvParameterSpec ivSpec = new IvParameterSpec(initVector);

        fullmessage = Arrays.copyOfRange(fullmessage, 8, fullmessage.length);

        // Decrypt:
        cipher.init(Cipher.DECRYPT_MODE, specKey, ivSpec);

        int enc_len = fullmessage.length;

        byte[] decrypted = new byte[cipher.getOutputSize(enc_len)];
        int dec_len = cipher.update(fullmessage, 0, enc_len, decrypted, 0);
        dec_len += cipher.doFinal(decrypted, dec_len);

        fullmessage = decrypted;

        String theFilename = "tempFile";

        if(fullmessage[0] == 'S') {

            byte[] fileData = null;

            for (int i = 1; i <= 200; i++) {
                if (fullmessage[i] == '/') {
                    theFilename = new String(Arrays.copyOfRange(fullmessage, 1, i));
                    fileData = Arrays.copyOfRange(fullmessage, i + 1, dec_len);
                    break;
                }
            }

            System.out.println("Received File: [" + theFilename + "]");

            BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(receivedFilesPath + displayedChatRoom + "/" + theFilename));

            bos.write(fileData);
            bos.flush();
            bos.close();

            System.out.println("Saved File. [" + theFilename + "]");

            // Have to do like this as cannot change text from separate thread (non fx thread)
            windowController.receivedFile = theFilename;
            Platform.runLater(() -> windowController.receivedImage());
        } else if (fullmessage[0] == 'C'){ // Change request
            theFilename = new String(Arrays.copyOfRange(fullmessage, 1, dec_len));

            System.out.println("Changing by request to: "+theFilename);

            windowController.fileChangedTo = theFilename;
            Platform.runLater(() -> windowController.receivedChangeRequest());
        } else if (fullmessage[0]=='A'){ // Announcement of online status
            String clientId = new String(Arrays.copyOfRange(fullmessage, 2, dec_len));

            windowController.clientChangingStatus = clientId;

            if (fullmessage[1]=='Y'){
                Platform.runLater(() -> windowController.updateOnline());
            }
            else{
                Platform.runLater(() -> windowController.updateOffline());
            }
        } else if (fullmessage[0]=='O'){ // Online status request
            System.out.println("All Online status request received.");
            new Thread(() -> sendingAllOnlineClients()).start();
        } else if (fullmessage[0] =='B'){ //Announcement of all online
            if (requestingOnlineStatus){ // Ignore any messages after first
                requestingOnlineStatus = false;
                System.out.println("Online status of all clients received.");

                String fullString = new String(Arrays.copyOfRange(fullmessage, 1, dec_len));

                String[] allNames = fullString.split("/#/");

                windowController.onlineClients.clear();

                for (String name : allNames){
                    windowController.onlineClients.add(name);
                }

                Platform.runLater(() -> windowController.refreshUserList());
            }

        }
        else{
            System.out.println("Invalid Message: "+new String(fullmessage));
        }
    } // messageArrived()

    // This function is called every time a message has been delivered to the server
    @Override
    public void deliveryComplete(IMqttDeliveryToken token) {
        // TODO Auto-generated method stub
        System.out.println("Delivery Complete!");
    } // deliveryComplete()

} // public class ServerCommunicator
