package sample;

import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.util.Callback;

import java.io.*;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;

public class Controller implements Initializable {

    public static Stage mainStage;

    public static final Color goodColour = Color.web("009f1a");
    public static final Color badColour = Color.RED;
    public static final Color neutralColour = Color.BLACK;

    public static final String youIdentifier = " (You)";

    public Button connectButton;
    public Button sendFileButton;

    public TextField clientIdField;
    public TextField chatRoomField;
    public TextField fileToSendField;

    public String receivedFile = "";

    public String fileChangedTo = "";

    public Label statusBar;

    public Label connectionStatus;

    public Pane mainImagePane;

    public ListView fileList;

    public ListView userList;

    public String relativeFilepath;

    public String currentRoom;

    public String fileToSend;

    public String pathToSend;

    public String clientChangingStatus;

    public String currentClientName = "";

    public boolean sending = false;

    public boolean connecting = false;

    public ArrayList<String> onlineClients;

    private boolean dontSendRequest = false;

    public static ServerCommunicator serverCommunicator;

    public static final String baseTopic = "DavidWhite164839156";

    public static final String baseChatRoom = baseTopic+"/Rooms/";

    public static final String settingsFilename = "savedSettings";

    public Controller(){
        serverCommunicator = new ServerCommunicator(this);

        relativeFilepath = new File("").getAbsolutePath();
        if (relativeFilepath.contains("/"))
            relativeFilepath+="/Received Files/";
        else
            relativeFilepath += "\\Received Files\\";
    } // constructor

    // This function initialises the clientId and chatRoom fields to be equal to the
    // saved values and initialises the GUI lists + makes Received files directory
    @Override
    public void initialize(URL location, ResourceBundle resources){
        File settingsFile = new File(relativeFilepath+settingsFilename);

        if(settingsFile.isFile()){
            try{
                List<String> lines = Files.readAllLines(Paths.get(relativeFilepath+settingsFilename), Charset.defaultCharset());
                clientIdField.setText(lines.get(0));
                chatRoomField.setText(lines.get(1));
            }
            catch (Exception e){
                System.err.println("An error has occured.");
                System.err.println(e.getMessage());
            }
        }

        fileList.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);

        // This adds listener which checks when any selection changes occur on the list box
        fileList.getSelectionModel().selectedItemProperty().addListener(
                new ChangeListener<String>() {
                    public void changed(ObservableValue<? extends String> ov,
                                        String old_val, String new_val) {
                        new Thread(() -> processFileListClick(new_val)).start();
                    }
                });

        fileList.setCellFactory(new Callback<ListView<String>,
                                        ListCell<String>>() {
                                    @Override
                                    public ListCell<String> call(ListView<String> fileList) {
                                        return new ImageCell();
                                    }
                                }
        );

        File folder = new File(relativeFilepath);

        if(!folder.isDirectory()){
            folder.mkdir();
        }

        onlineClients = new ArrayList<>();

    } // initialize()

    // This function is called on every change in selection of the file list - changes
    // the image in frame to be the one selected and sends out a request for all clients
    // to also change to this image
    public void processFileListClick(String new_val){
        changeToImageInFrame(new_val);
        if(!dontSendRequest && new_val!=null){
            serverCommunicator.sendChangeRequest(new_val);
        } else {dontSendRequest = false;}
    } // processFileListClick()

    // This function adds all files in the correct room folder
    // to the list of sent/received files
    public void populateFileList(){

        File folder = new File(relativeFilepath+currentRoom);

        File[] listOfFiles = folder.listFiles();

        if (listOfFiles != null) {
            // Sort into reverse time order
            Arrays.sort(listOfFiles, new Comparator() {
                public int compare(Object o1, Object o2) {

                    if (((File) o1).lastModified() > ((File) o2).lastModified()) {
                        return +1;
                    } else if (((File) o1).lastModified() < ((File) o2).lastModified()) {
                        return -1;
                    } else {
                        return 0;
                    }
                }

            });

            for (File i : listOfFiles) {
                if (!i.getName().equals(settingsFilename)) {
                    addToList(relativeFilepath + currentRoom + "/" + i.getName());
                }
            }
        }
        else{
            folder.mkdir();
        }
    } // populateFileList()

    // This function is called on clicking the connect button. If both clientId and chat
    // room are valid, connection is attempted using these details.
    public void connectButtonClicked(){
        String clientName = clientIdField.getText();
        String chatRoomName = chatRoomField.getText();

        // Strip Whitespace
        clientName = clientName.trim();//.replaceAll("\\s+","");
        chatRoomName = chatRoomName.trim();

        if (clientName.equals("") || chatRoomName.equals("")){
            statusBar.setTextFill(badColour);
            statusBar.setText("You must enter a username and a room name.");
        }
        else
        {
            if(!connecting){
                try {
                    onlineClients.clear();

                    userList.getItems().clear();
                    //removeFromUserList(currentClientName+" (You)");

                    currentRoom = chatRoomName;
                    currentClientName = clientName;

                    connectingScreenUpdate();

                    fileList.getItems().clear();

                    connecting = true;

                    // Pass variables to server communicators before threading the connection process
                    serverCommunicator.setupVariables(baseChatRoom, clientName, chatRoomName, relativeFilepath);

                    new Thread(() -> serverCommunicator.setupAll()).start();
                }
                catch (Exception e){
                    statusBar.setTextFill(badColour);
                    statusBar.setText("An Error Occurred While Trying To Connect");
                    System.err.println("An error has occurred.");
                    System.err.println(e.getMessage());
                }
            }
            else{
                statusBar.setTextFill(badColour);
                statusBar.setText("You Are Already Connecting!");
            }
        }
    } // connectButtonClicked()

    // Function used by the ServerCommunicator object to update the display
    // from non GUI thread
    public void connectingScreenUpdate(){
        statusBar.setTextFill(Controller.neutralColour);
        statusBar.setText("Connecting to "+currentRoom+" as "+currentClientName+". Please Wait...");

        connectionStatus.setText("Connecting to "+currentRoom+" as "+currentClientName+". Please Wait...");
        connectionStatus.setTextFill(Controller.neutralColour);

    } // connectingScreenUpdate()

    // Function used by the ServerCommunicator object to update the display
    // from non GUI thread
    public void successfulConnectionUpdate(){
        connectionStatus.setText("Connected! - Room: "+currentRoom+" / Username: "+currentClientName);
        connectionStatus.setTextFill(Controller.goodColour);

        statusBar.setTextFill(Controller.goodColour);
        statusBar.setText("Connected to Room: "+currentRoom+" / Username: "+currentClientName+".");

        addToUserList(currentClientName+youIdentifier, true);

        try {
            PrintWriter settingsOut = new PrintWriter(relativeFilepath + "savedSettings");

            settingsOut.println(currentClientName);
            settingsOut.println(currentRoom);

            settingsOut.close();
        }catch (Exception e){
            System.err.println("An error occured whilst trying to save the settings.");
        }

        populateFileList();

        connecting = false;
    } // successfulConnectionUpdate()

    // Function used by the ServerCommunicator object to update the display
    // from non GUI thread
    public void failedConnectionUpdate(){
        connectionStatus.setText("Failed to connect to "+currentRoom+" with username: "+currentClientName);
        connectionStatus.setTextFill(Controller.badColour);

        statusBar.setTextFill(Controller.badColour);
        statusBar.setText("Failed to connect to "+currentRoom+" with username: "+currentClientName);

        connecting = false;
    } // failedConnectionUpdate()

    // This ImageCell object is used as all entries in the list of files - this object
    // allows image previews to be placed alongside the name of the file
    static class ImageCell extends ListCell<String>{
        @Override
        public void updateItem(String item, boolean empty){
            super.updateItem(item, empty);

            if (item != null && !empty) {

                // Loads image at width 100, height=0(ignored) preserve ratio and non-smooth
                Image image = new Image("file:///"+item, 100, 0, true, false);

                ImageView imageView = new ImageView(image);
                imageView.setFitWidth(100);
                imageView.setPreserveRatio(true);
                imageView.setCache(true);
                imageView.setSmooth(false);
                setGraphic(imageView);

                setStyle("-fx-font-size: 10px;");

                String[] splitFilepath;

                if (item.contains("/"))
                    splitFilepath = item.split("/");
                else
                    splitFilepath = item.split("\\\\");

                String filename = ServerCommunicator.getOriginalFilename(splitFilepath[splitFilepath.length-1]);

                StringBuilder filenameString = new StringBuilder(filename);

                int wordWrapOffset = 15;

                int offsetCount = wordWrapOffset;

                while (offsetCount < filenameString.length()){
                    filenameString.insert(offsetCount, '\n');
                    offsetCount+=wordWrapOffset+1;
                }

                setText(filenameString.toString());
            }
            else {
                // Makes cells that should be empty appear to actually be empty - If not updated, can cause cells to
                // still have images and/or text
                setText("");
                setGraphic(null);
            }
        } // updateItem()
    } // class ImageCell

    // This function refreshes the users that are in the list of users.
    public void refreshUserList(){
        userList.getItems().clear();

        for (String name : onlineClients){
            if (!name.equals(currentClientName)) {
                userList.getItems().add(name);
            }else{
                userList.getItems().add(name+youIdentifier);
            }
        }
    } // refreshUserList()

    // This function adds the given user to the list
    public void addToUserList(String clientId, boolean you){
        userList.getItems().add(clientId);
        if(!you)
            onlineClients.add(clientId);
        else
            onlineClients.add(currentClientName);
    } // addToUserList()

    // This function removes the given user from the list
    public void removeFromUserList(String clientId){
        userList.getItems().remove(clientId);
        onlineClients.remove(clientId);
    } // removeFromUserList()

    // This function adds the given file to the file list
    public void addToList(String filepath){
        fileList.getItems().add(0, filepath);
    } // addToList()

    // This function changes the images in the frame to the given file
    public void changeToImageInFrame(String filePath){
        if(filePath != null) {
            File file = new File(filePath);

            if (file.isFile()) {
                String path = file.toURI().toASCIIString();

                mainImagePane.setStyle("-fx-background-image: url(\"" + path + "\");\n" +
                        "    -fx-background-repeat: no-repeat;   \n" +
                        "    -fx-background-size: contain;\n" +
                        "    -fx-background-position: center center;");
            }
        }
        else{
            mainImagePane.setStyle("-fx-background-image: none;");
        }
    } // changeToImageInFrame()

    // This function is called upon receipt of a new image. It automatically changes
    // to the new image and states that a new file has been received
    public void receivedImage(){
        addToList(relativeFilepath+currentRoom+"/"+receivedFile);

        dontSendRequest = true;
        fileList.getSelectionModel().select(relativeFilepath+currentRoom+"/"+receivedFile);
        fileList.scrollTo(relativeFilepath+currentRoom+"/"+fileChangedTo);
        //changeToImageInFrame(relativeFilepath+currentRoom+"/"+receivedFile, false);

        statusBar.setTextFill(Controller.goodColour);
        statusBar.setText("Received File: "+ ServerCommunicator.getOriginalFilename(receivedFile));
    } // receivedImage()

    // This function is called upon receipt of change image request - changes image
    // to the one requested. This still needs to be adjusted by making sure that
    // the user actually has the requested file, and if not, request it.
    public void receivedChangeRequest(){
        // Need to check if actually have file

        //changeToImageInFrame(relativeFilepath+currentRoom+"/"+fileChangedTo);
        dontSendRequest = true;
        fileList.getSelectionModel().select(relativeFilepath+currentRoom+"/"+fileChangedTo);

        fileList.scrollTo(relativeFilepath+currentRoom+"/"+fileChangedTo);
    } // receivedChangeRequest()

    // This function is called when online status is received and updates the online users
    // list appropriately by adding them to the list
    public void updateOnline(){
        removeFromUserList(clientChangingStatus); // Just in case person is already on list.
        addToUserList(clientChangingStatus, false);
        System.out.println(clientChangingStatus+" is online.");
    } // updateOnline()

    // This function is called when offline status is received and updates the online users
    // list appropriately by removing them from the list
    public void updateOffline(){
        removeFromUserList(clientChangingStatus);
        System.out.println(clientChangingStatus+" is offline.");
    } // updateOffline()

    // This function is called upon pressing the send button. Function gets the filepath
    // from the box and attempts to send it to the server
    public void sendButtonClicked(){
        if (serverCommunicator.client != null && serverCommunicator.client.isConnected()) {
            if(!sending){
                String path = fileToSendField.getText().trim();
                File f = new File(path);
                if (f.isFile()) {
                    try {
                        String filename = serverCommunicator.getSentFilename(path);

                        sending = true;
                        new Thread(() -> serverCommunicator.sendFile(path, filename)).start();

                        pathToSend = path;
                        fileToSend = filename;

                        statusBar.setTextFill(neutralColour);
                        statusBar.setText("Sending File: "+ path);

                    } catch (Exception e) {
                        statusBar.setTextFill(badColour);
                        statusBar.setText("An Error Occurred While Sending: "+ path);
                        System.err.println("An error has occurred.");
                        System.err.println(e.getMessage());
                    }
                } else {
                    statusBar.setTextFill(badColour);
                    statusBar.setText("That File Does Not Exist!");
                }
            } else {
                statusBar.setTextFill(badColour);
                statusBar.setText("You Are Already Sending A File! ("+ pathToSend+")");
            }
        }
        else {
            statusBar.setTextFill(badColour);
            statusBar.setText("You Are Not Connected To The Server!");
        }
    } // sendButtonClicked()

    // This function updates the frame to display the image just sent by user
    public void updateMainDisplayToRecentImage(){
        addToList(relativeFilepath+currentRoom+"/"+fileToSend);

        dontSendRequest = true;
        fileList.getSelectionModel().select(relativeFilepath+currentRoom+"/"+fileToSend);

        fileList.scrollTo(0);
    } // updateMainDisplayToRecentImage()

    // This function copies sent file into received files to ensure they are all in
    // the same place
    public void copyFileToReceived(){
        File f = new File(pathToSend);

        File newCopy = new File(relativeFilepath+currentRoom+"/"+fileToSend);

        if (newCopy.isFile()){
            newCopy.delete(); //del
            //remove
        }

        // This update time to make them sorted in the correct order
        f.setLastModified(System.currentTimeMillis());
        newCopy.setLastModified(System.currentTimeMillis());

        try{
            Files.copy(f.toPath(),newCopy.toPath());}
        catch (Exception e){
            System.err.println("Error occured whilst copying file to receieved files.");
        }

        Platform.runLater(() -> updateMainDisplayToRecentImage());
    } // copyFileToReceived()

    // Function used by the ServerCommunicator object to update the display
    // from non GUI thread
    public void sendSuccessfulUpdate(){
        fileToSendField.setText("");
        new Thread(() -> copyFileToReceived()).start();

        sending = false;

        statusBar.setTextFill(goodColour);
        statusBar.setText("Successfully Sent File: "+ pathToSend);
    } // sendSuccessfulUpdate()

    // Function used by the ServerCommunicator object to update the display
    // from non GUI thread
    public void sendFailedUpdate(){
        sending = false;
        statusBar.setTextFill(badColour);
        statusBar.setText("File Sending Failed: "+ pathToSend);
    } // sendFailedUpdate()

    // This function is called on pressing the browse button and allows the user
    // to browse their file system for a file to send
    public void browseButtonClicked(){
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Send File");
        File fileToSend = fileChooser.showOpenDialog(mainStage);

        if (fileToSend != null)
            fileToSendField.setText(fileToSend.getPath());
    } // browseButtonClicked()

} // public class Controller
