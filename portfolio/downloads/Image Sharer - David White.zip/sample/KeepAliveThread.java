package sample;

public class KeepAliveThread extends Thread{

    ServerCommunicator theServer;

    boolean threadKilled;

    public KeepAliveThread(ServerCommunicator newServer){
        theServer = newServer;
        threadKilled = false;
    }

    // While running, the server will be sent a message at the
    // interval given in the ServerCommunicator.keepAliveInterval
    // Thread can only be stopped if interrupted
    public void run(){
        while(!threadKilled){
            theServer.keepAlive();
            try{
                Thread.sleep(ServerCommunicator.keepAliveInterval);
            } catch(InterruptedException e){
                threadKilled = true;
            }
        }
    }
}
