'''
Code written by David White.
This code is available under the Creative Commons Attribution-NonCommercial 4.0 International License.
http://creativecommons.org/licenses/by-nc/4.0/
'''
from tkinter import *
import tkinter.ttk as ttk
from nredarwin.webservice import DarwinLdbSession
from datetime import datetime
import os

darwinAPIKey = "" # Need to set this to be equal to a valid Darwin API key for it to work

stationCode = 'MAN'
stationName = "Manchester Piccadilly"

departureBoardTime = 40
advertTIme = 20

secondsBetweenUpdates = 45

errorRefreshSeconds = 5

'''

TODO:
Add more try/excepts to avoid fatal errors from possible problems with badly parsing
response from server.

'''

# This class contains all the code for the GUI and functions to access and display data
class MainApp:

    # Constructor to initialise the GUI and variables
    def __init__(self, master):

        self.appMaster = master

        self.adScreens = []

        folderList = os.listdir("./Advert_Screens/")

        for theFile in folderList:
            if theFile[-4:] == ".png":
                self.adScreens.append(PhotoImage(file="./Advert_Screens/"+theFile))

        self.adIndex = 0

        self.oldLength = len(self.adScreens)

        mainFrame = Frame(master, bg=bgColour)
        mainFrame.pack(fill=BOTH, expand=1)

        topFrame = Frame(mainFrame, bg=topFrameColour, pady=int(20  * screen_height/1080))
        topFrame.pack(side=TOP, fill=BOTH)

        leftPadding = Label(topFrame, width=10, bg=topFrameColour)
        leftPadding.pack(side=LEFT)

        rightPadding = Label(topFrame, width=10, bg=topFrameColour)
        rightPadding.pack(side=RIGHT)

        w = Label(topFrame, bg=topFrameColour)
        w.pack(side=LEFT)

        leftGapPadding = Label(topFrame, width=int(15  * screen_width/1920), bg=topFrameColour)
        leftGapPadding.pack(side=LEFT)

        topLabel = Label(topFrame, text=stationName+" Train Station Live Departures", font=(typeface + " bold",topLabelFontsize), fg=headingFontColour, bg=topFrameColour)
        topLabel.pack(side=LEFT)

        self.currentHours = 0
        self.currentMins = 0
        self.currentSecs = 0

        self.timeLabel = Label(topFrame, text="XX:XX", font=(typeface, timeFontsize), fg=timeFontColour, bg= topFrameColour)
        self.timeLabel.pack(side=RIGHT)


        tableFrame = Frame(mainFrame, bg=bgColour)
        tableFrame.pack(side=TOP)

        bottomFrame = Frame(mainFrame, bg=topFrameColour)
        bottomFrame.pack(side=BOTTOM, fill=BOTH)

        self.bottomLabel = Label(bottomFrame, text=" ", font=(typeface, bottomLabelFontsize), fg=headingFontColour, bg=topFrameColour)
        self.bottomLabel.pack(side=TOP)

        xPadding = int(4  * screen_width/1920)
        yPadding = int(4  * screen_height/1080)

        self.tableHeadings = [Label(tableFrame, text="Depart Time"),
                                Label(tableFrame, text="Destination", width=18),
                                 Label(tableFrame, text="Status", width=14),
                                   Label(tableFrame, text="Platform")]

        self.row1 = [Label(tableFrame, text=defaultText),
                     Label(tableFrame, text=defaultText),
                     Label(tableFrame, text=defaultText),
                     Label(tableFrame, text=defaultText)]

        self.row2 = [Label(tableFrame, text=defaultText),
                     Label(tableFrame, text=defaultText),
                     Label(tableFrame, text=defaultText),
                     Label(tableFrame, text=defaultText)]

        self.row3 = [Label(tableFrame, text=defaultText),
                     Label(tableFrame, text=defaultText),
                     Label(tableFrame, text=defaultText),
                     Label(tableFrame, text=defaultText)]

        self.row4 = [Label(tableFrame, text=defaultText),
                     Label(tableFrame, text=defaultText),
                     Label(tableFrame, text=defaultText),
                     Label(tableFrame, text=defaultText)]

        self.row5 = [Label(tableFrame, text=defaultText),
                     Label(tableFrame, text=defaultText),
                     Label(tableFrame, text=defaultText),
                     Label(tableFrame, text=defaultText)]

        self.row6 = [Label(tableFrame, text=defaultText),
                     Label(tableFrame, text=defaultText),
                     Label(tableFrame, text=defaultText),
                     Label(tableFrame, text=defaultText)]

        self.row7 = [Label(tableFrame, text=defaultText),
                     Label(tableFrame, text=defaultText),
                     Label(tableFrame, text=defaultText),
                     Label(tableFrame, text=defaultText)]

        self.row8 = [Label(tableFrame, text=defaultText),
                     Label(tableFrame, text=defaultText),
                     Label(tableFrame, text=defaultText),
                     Label(tableFrame, text=defaultText)]

        self.row9 = [Label(tableFrame, text=defaultText),
                     Label(tableFrame, text=defaultText),
                     Label(tableFrame, text=defaultText),
                     Label(tableFrame, text=defaultText)]

        self.row10 = [Label(tableFrame, text=defaultText),
                     Label(tableFrame, text=defaultText),
                     Label(tableFrame, text=defaultText),
                     Label(tableFrame, text=defaultText)]

        # For all columns
        for i in range(0, len(self.row1)):
            self.tableHeadings[i].config(fg=headingFontColour, bg=bgColour, font=(typeface, headingFontsize), padx=xPadding, pady=yPadding)
            self.row1[i].config(fg=textColour, bg=bgColour, font=(typeface, fontsize), padx=xPadding, pady=yPadding)
            self.row2[i].config(fg=textColour, bg=bgColour, font=(typeface, fontsize), padx=xPadding, pady=yPadding)
            self.row3[i].config(fg=textColour, bg=bgColour, font=(typeface, fontsize), padx=xPadding, pady=yPadding)
            self.row4[i].config(fg=textColour, bg=bgColour, font=(typeface, fontsize), padx=xPadding, pady=yPadding)
            self.row5[i].config(fg=textColour, bg=bgColour, font=(typeface, fontsize), padx=xPadding, pady=yPadding)
            self.row6[i].config(fg=textColour, bg=bgColour, font=(typeface, fontsize), padx=xPadding, pady=yPadding)
            self.row7[i].config(fg=textColour, bg=bgColour, font=(typeface, fontsize), padx=xPadding, pady=yPadding)
            self.row8[i].config(fg=textColour, bg=bgColour, font=(typeface, fontsize), padx=xPadding, pady=yPadding)
            self.row9[i].config(fg=textColour, bg=bgColour, font=(typeface, fontsize), padx=xPadding, pady=yPadding)
            self.row10[i].config(fg=textColour, bg=bgColour, font=(typeface, fontsize), padx=xPadding, pady=yPadding)

            self.tableHeadings[i].grid(row=0, column=i)
            self.row1[i].grid(row=1, column=i)
            self.row2[i].grid(row=2, column=i)
            self.row3[i].grid(row=3, column=i)
            self.row4[i].grid(row=4, column=i)
            self.row5[i].grid(row=5, column=i)
            self.row6[i].grid(row=6, column=i)
            self.row7[i].grid(row=7, column=i)
            self.row8[i].grid(row=8, column=i)
            self.row9[i].grid(row=9, column=i)
            self.row10[i].grid(row=10, column=i)

        self.autoUpdateTime()
        self.updateTable()

        self.secondsOfTrains = departureBoardTime
        self.secondsOfAdverts = advertTIme

        self.showingAdvert = False

        self.advertOverlay = Toplevel()

        w, h = master.winfo_screenwidth(), master.winfo_screenheight()
        self.advertOverlay.overrideredirect(1)
        self.advertOverlay.geometry("%dx%d+0+0" % (w, h))
        self.advertOverlay.config(cursor="none")
        self.advertOverlay.bind("<Escape>", lambda e: e.widget.quit())

        self.AdPhotoLabel = Label(self.advertOverlay, bg="#000", fg="#F00")
        self.AdPhotoLabel.pack(side=TOP, fill=BOTH, expand=1)

        self.appMaster.after(1000*self.secondsOfTrains, self.toggleAdvert)


    # Function which is automatically run every 500 milliseconds to update the time on the display
    def autoUpdateTime(self):
        self.updateTime()
        self.appMaster.after(500, self.autoUpdateTime)


    # Function to get the current time from the PC update the current time on the display
    def updateTime(self):
        currentTimeString = str(datetime.now().time())[0:8]

        self.currentHours = currentTimeString[0:2]
        self.currentMins = currentTimeString[3:5]
        self.currentSecs = currentTimeString[6:8]

        self.timeLabel.config(text=self.currentHours + ":" + self.currentMins)# + ":" + self.currentSecs)

        self.currentHours = int(self.currentHours)
        self.currentMins = int(self.currentMins)
        self.currentSecs = int(self.currentSecs)      


    # Function to convert the time into a value that can be used to order the services correctly
    def timeStringToValue(self, timeString):
        try:
            boundary = self.currentHours - 12

            if boundary < 0:
                boundary = boundary + 24

            hours = int(timeString[0:2])
            if hours < boundary:
                hours = 24 + hours
            convertedValue = hours*60 + int(timeString[3:5])
        except:
            convertedValue = 0
        return convertedValue


    # Update every row of the table to display the next 10 services
    def updateTable(self):
        self.updateTime() # Update time to try and disguise pauses in counting

        try:
            self.darwin_session = DarwinLdbSession(wsdl="https://lite.realtime.nationalrail.co.uk/OpenLDBWS/wsdl.aspx", api_key=darwinAPIKey)
            board = self.darwin_session.get_station_board(stationCode, include_arrivals=False)

            numberOfTrainServices = len(board.train_services)

            numberOfBusServices = len(board.bus_services)

            numberOfServices =  numberOfBusServices + numberOfTrainServices 

            nextTrainService = 0

            nextBusService = 0

            services = []

            for i in range(0, numberOfServices):

                # If there are bus and train services left
                if numberOfBusServices > nextBusService and numberOfTrainServices > nextTrainService:

                    if self.timeStringToValue(board.train_services[nextTrainService].std) <= self.timeStringToValue(board.bus_services[nextBusService].std):
                        services.append(board.train_services[nextTrainService])
                        nextTrainService = nextTrainService + 1
                    else:
                        services.append(board.bus_services[nextBusService])
                        nextBusService = nextBusService + 1

                # Else if only bus services left
                elif numberOfBusServices > nextBusService and numberOfTrainServices <= nextTrainService:
                    services.append(board.bus_services[nextBusService])
                    nextBusService = nextBusService + 1

                # Else if only train services left
                elif numberOfBusServices <= nextBusService and numberOfTrainServices > nextTrainService:
                    services.append(board.train_services[nextTrainService])
                    nextTrainService = nextTrainService + 1


            serviceIndex = 0

            if numberOfServices >= 1:
                self.updateRow(services[serviceIndex], self.row1)
                serviceIndex = serviceIndex + 1
            else:
                self.clearRow(self.row1)


            if numberOfServices >= 2:
                self.updateRow(services[serviceIndex], self.row2)
                serviceIndex = serviceIndex + 1
            else:
                self.clearRow(self.row2)


            if numberOfServices >= 3:
                self.updateRow(services[serviceIndex], self.row3)
                serviceIndex = serviceIndex + 1
            else:
                self.clearRow(self.row3)

            if numberOfServices >= 4:
                self.updateRow(services[serviceIndex], self.row4)
                serviceIndex = serviceIndex + 1
            else:
                self.clearRow(self.row4)

            if numberOfServices >= 5:
                self.updateRow(services[serviceIndex], self.row5)
                serviceIndex = serviceIndex + 1
            else:
                self.clearRow(self.row5)

            if numberOfServices >= 6:
                self.updateRow(services[serviceIndex], self.row6)
                serviceIndex = serviceIndex + 1
            else:
                self.clearRow(self.row6)

            if numberOfServices >= 7:
                self.updateRow(services[serviceIndex], self.row7)
                serviceIndex = serviceIndex + 1
            else:
                self.clearRow(self.row7)

            if numberOfServices >= 8:
                self.updateRow(services[serviceIndex], self.row8)
                serviceIndex = serviceIndex + 1
            else:
                self.clearRow(self.row8)

            if numberOfServices >= 9:
                self.updateRow(services[serviceIndex], self.row9)
                serviceIndex = serviceIndex + 1
            else:
                self.clearRow(self.row9)

            if numberOfServices >= 10:
                self.updateRow(services[serviceIndex], self.row10)
            else:
                self.clearRow(self.row10)


            hoursString = str(self.currentHours)

            if len(hoursString) < 2:
                hoursString = "0" + hoursString


            minsString = str(self.currentMins)

            if len(minsString) < 2:
                minsString = "0" + minsString


            secsString = str(self.currentSecs)

            if len(secsString) < 2:
                secsString = "0" + secsString

            # Update bottom label
            self.bottomLabel.config(text="Last Updated At: " + hoursString + ":" + minsString + ":" + secsString, fg=headingFontColour)

            self.appMaster.after(1000*secondsBetweenUpdates, self.updateTable)

        except:

            if self.bottomLabel.cget("fg") != internetConnectionErrorColour:
                lastMessage = self.bottomLabel.cget("text")

                self.bottomLabel.config(text=lastMessage + " - AN ERROR HAS OCCURRED - CANNOT ACCESS THE SERVER", fg=internetConnectionErrorColour)


            self.appMaster.after(1000*errorRefreshSeconds, self.updateTable)


    # This function toggles between showing an advert on the screen, and showing the train times
    # This function is automatically run at set intervals defined by the departureBoardTime and
    # advertTime variables
    def toggleAdvert(self):

        if self.showingAdvert:
            self.appMaster.grab_set()
            self.appMaster.focus_set()
            self.showingAdvert = False
            self.appMaster.after(1000*self.secondsOfTrains, self.toggleAdvert)
        else:
            folderList = os.listdir("./Advert_Screens/")

            newTempList = []

            for theFile in folderList:
                if theFile[-4:] == ".png":
                    newTempList.append("./Advert_Screens/" + theFile)

            if self.oldLength != len(newTempList):

                self.adScreens = []

                for i in newTempList:
                    self.adScreens.append(PhotoImage(file=i))

                self.adIndex = 0

            if len(self.adScreens) > 0:
                photo = self.adScreens[self.adIndex]
                self.AdPhotoLabel.config(image=photo, text="")
                self.AdPhotoLabel.photo = photo

                self.adIndex = self.adIndex + 1

                if self.adIndex >= len(self.adScreens):
                    self.adIndex = 0
            else:
                self.AdPhotoLabel.config(text="No Advert Images Found", image="")

            self.AdPhotoLabel.update()
            self.advertOverlay.grab_set()
            self.advertOverlay.focus_set()
            self.showingAdvert = True
            self.oldLength = len(self.adScreens)
            self.appMaster.after(1000*self.secondsOfAdverts, self.toggleAdvert)


    # The row given in the function call will be updated to display the given service correctly
    def updateRow(self, service, row):

        statusMessage = service.etd

        rowColour = textColour

        platform = service.platform

        if platform is None:
            platform = "-"
        elif platform == "BUS":
            rowColour = busTextColour

        if statusMessage is None:
            statusMessage = " " # Just in case
        elif len(statusMessage) == 5 and statusMessage[2] == ':':
            statusMessage = "Due At: " + statusMessage
            rowColour = notOnTimeColour
        elif statusMessage == "Cancelled":
            rowColour = cancelledColour
        elif statusMessage != "On time":
            rowColour = notOnTimeColour

        row[0].config(text=service.std, fg=rowColour)
        row[1].config(text=service.destination_text, fg=rowColour)

        if len (service.destination_text) > 23:
            row[1].config(font=(typeface, int(fontsize*0.7)))
        else:
            row[1].config(font=(typeface, fontsize))


        row[2].config(text=statusMessage, fg=rowColour)
        row[3].config(text=platform, fg=rowColour)
        

    # This function clears the specified row completely
    def clearRow(self, row):
        row[0].config(text=" ")
        row[1].config(text=" ")
        row[2].config(text=" ")
        row[3].config(text=" ")




root = Tk()
root.wm_title("Station Board")

# make it cover the entire screen
w, h = root.winfo_screenwidth(), root.winfo_screenheight()
root.overrideredirect(1)
root.geometry("%dx%d+0+0" % (w, h))

root.focus_set() # move focus to this widget
root.bind("<Escape>", lambda e: e.widget.quit())
root.config(cursor="none")

screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()

''' Variables: '''

typeface = "Arial"
headingFontsize = int(48 * screen_width/1920)
headingFontColour = "#FFF"

timeFontsize = int(72 * screen_width/1920)
timeFontColour = "#EEE"

fontsize = int(44  * screen_width/1920)

bottomLabelFontsize = int(16  * screen_width/1920)

topLabelFontsize = int(36  * screen_width/1920)
 
textColour = "#b4d6f2"#"#DDF"     #"#0F3"   

notOnTimeColour = "#ec2727"

cancelledColour = "#F00"

busTextColour = "#eb763c"

defaultText = "ERROR"

bgColour = "#080808"

topFrameColour = "#0F0F0F"

internetConnectionErrorColour = "#F00"

'''-----------------------------------------'''

newObject = MainApp(root)

root.configure(background='#111')

root.mainloop()